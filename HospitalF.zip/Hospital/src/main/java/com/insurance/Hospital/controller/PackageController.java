package com.insurance.Hospital.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.Hospital.contractors.PackageServiceInterface;
import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.InsurancePackage;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class PackageController {

	PackageServiceInterface packageServiceInterface;

	@Autowired
	public PackageController(PackageServiceInterface packageServiceInterface) {
		this.packageServiceInterface = packageServiceInterface;
	}

	@GetMapping("/start")
	public String getAllInsurancePackages(Model model) {
		// Retrieve data from the service
		List<InsurancePackage> insurancePackages = packageServiceInterface.getAllInsurancePackages();
		// Add the data to the model for rendering in the Thymeleaf template
		model.addAttribute("insurancePackages", insurancePackages);
		// Return the name of the Thymeleaf template to render
		return "packages";
	}

	@GetMapping("/filteredpackages")
	public String getFilteredPackages(@RequestParam("status") String status, @RequestParam("age") String age,
			Model model) {
		// Print the 'status' parameter to the console for debugging purposes.
		System.out.println(status);

		// Check if 'status' is "ALL" and 'age' is empty.
		if ("ALL".equals(status) && age.equals("")) {
			System.out.println("if");

			// Retrieve all insurance packages from the service.
			List<InsurancePackage> insurancePackages = packageServiceInterface.getAllInsurancePackages();
			// Add the insurancePackages to the model for rendering in the view.
			model.addAttribute("insurancePackages", insurancePackages);

			// Return the name of the view to be displayed (in this case, "packages").
			return "packages";
		} else if ("ALL".equals(status) && !age.equals("")) {
			System.out.println("if");

			// Retrieve insurance packages by age from the service.
			List<InsurancePackage> insurancePackages = packageServiceInterface
					.getAllInsurancePackagesByAge(Integer.parseInt(age));

			// Add the insurancePackages to the model for rendering in the view.
			model.addAttribute("insurancePackages", insurancePackages);

			// Return the name of the view to be displayed (in this case, "packages").
			return "packages";
		} else {
			// Handle other cases when 'status' is not "ALL".

			// Check if 'age' is empty.
			if (age.equals("")) {
				// Retrieve insurance packages by status from the service.
				List<InsurancePackage> insurancePackages = packageServiceInterface.getPackagesByStatus(status);

				// Add the insurancePackages to the model for rendering in the view.
				model.addAttribute("insurancePackages", insurancePackages);

				// Return the name of the view to be displayed (in this case, "packages").
				return "packages";
			} else {
				// Handle the case when 'age' is not empty.

				// Retrieve filtered insurance packages by status and age from the service.
				List<InsurancePackage> packages = packageServiceInterface.getFiteredDiseases(status,
						Integer.parseInt(age));

				// Add the filtered insurance packages to the model for rendering in the view.
				model.addAttribute("insurancePackages", packages);

				// Print the filtered packages and 'age' to the console for debugging purposes.
				System.out.println(packages);
				System.out.println(age);

				// Return the name of the view to be displayed (in this case, "packages").
				return "packages";
			}
		}
	}

	@RequestMapping(value = "/excel")
	public void downloadExcel(@RequestParam("status") String status, @RequestParam("age") String age,
	        HttpServletResponse response) throws IOException {
	    // Initialize a list to store insurance packages.
	    List<InsurancePackage> insurancePackages = new ArrayList<>();
	    

	    if ("ALL".equals(status) && age.equals("")) {
	        System.out.println("if");
	        // Retrieve all insurance packages when 'status' is "ALL" and 'age' is empty.
	        insurancePackages = packageServiceInterface.getAllInsurancePackages();
	    } else if ("ALL".equals(status) && !age.equals("")) {
	        System.out.println("if");
	        // Retrieve all insurance packages by age when 'status' is "ALL" and 'age' is not empty.
	        insurancePackages = packageServiceInterface.getAllInsurancePackagesByAge(Integer.parseInt(age));
	    } else {
	        if (age.equals("")) {
	            // Retrieve insurance packages by status when 'age' is empty.
	            insurancePackages = packageServiceInterface.getPackagesByStatus(status);
	        } else {
	            // Retrieve filtered insurance packages by status and age.
	            insurancePackages = packageServiceInterface.getFiteredDiseases(status, Integer.parseInt(age));
	        }
	    }
	    
	    // Create a new Excel workbook and sheet.
	    Workbook workbook = new XSSFWorkbook();
	    org.apache.poi.ss.usermodel.Sheet sheet = workbook.createSheet("Packages List");
	    
	    // Create a header row and define column headings.
	    Row headerRow = sheet.createRow(0);
	    headerRow.createCell(0).setCellValue("PackageId");
	    headerRow.createCell(1).setCellValue("PackageTitle");
	    headerRow.createCell(2).setCellValue("Description");
	    headerRow.createCell(3).setCellValue("Status");
	    headerRow.createCell(4).setCellValue("Amount Start Range");
	    headerRow.createCell(5).setCellValue("Amount End Range");
	    headerRow.createCell(6).setCellValue("Age Limit Start");
	    headerRow.createCell(7).setCellValue("Age Limit End");

	    // Iterate through the insurance packages and populate the Excel sheet.
	    int rowIdx = 1;
	    for (InsurancePackage insurance : insurancePackages) {
	        Row row = sheet.createRow(rowIdx++);
	        row.createCell(0).setCellValue(insurance.getInspId());
	        row.createCell(1).setCellValue(insurance.getInspTitle());
	        row.createCell(2).setCellValue(insurance.getInspDescription());
	        row.createCell(3).setCellValue(insurance.getInspStatus());
	        row.createCell(4).setCellValue(insurance.getInspRangeStart());
	        row.createCell(5).setCellValue(insurance.getInspRangeEnd());
	        row.createCell(6).setCellValue(insurance.getInspAgeLimitStart());
	        row.createCell(7).setCellValue(insurance.getInspAgeLimitEnd());
	    }

	    // Set the response headers for Excel file download.
	    response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	    response.setHeader("Content-Disposition", "attachment; filename=packages.xlsx");
	    
	    // Get the response output stream and write the workbook data to it.
	    OutputStream outputStream = response.getOutputStream();
	    workbook.write(outputStream);
	    outputStream.close();
	}

	@GetMapping(value = "/diseases/{inspId}")
	public String getDiseases(@PathVariable int inspId, Model model) {
	    // Retrieve a list of disease details by the provided 'inspId'.
	    List<DiseaseDetails> diseases = packageServiceInterface.getDiseasesByPackageId(inspId);
	    
	    
	    // Create a variable 'insId' and set it to the provided 'inspId'.
	    int insId = inspId;
	    
	    // Add 'inspId' and 'diseases' to the model for rendering in the view.
	    model.addAttribute("inspId", insId);
	    model.addAttribute("diseases", diseases);
	    
	    // Return the name of the view to be displayed (in this case, "diseasedetails").
	    return "diseasedetails";
	}

}
