package com.insurance.Hospital.contractors;
import java.util.List;

import com.insurance.Hospital.models.DiseaseProcedures;


public interface DiseaseProceduresServiceInterface {
	
	List<DiseaseProcedures> getProceduresByDisId(int diseaseId);
}
