package com.insurance.Hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.Hospital.contractors.PaymentsServiceInterface;
import com.insurance.Hospital.models.Payments;

import jakarta.servlet.http.HttpSession;

@Controller
public class PaymentController {

	PaymentsServiceInterface paymentsServiceInterface;

	@Autowired
	public PaymentController(PaymentsServiceInterface paymentsServiceInterface, HttpSession httpSession) {
		this.paymentsServiceInterface = paymentsServiceInterface;
	}
	
	
	//To List all payments 
	@GetMapping("/payments")
	public String displayPayments(Model model) {
		//Get all payments
		List<Payments> payments = paymentsServiceInterface.getPayments();
		model.addAttribute("payments", payments);
		return "payments";
	}
	
	//To view Payment details
	@GetMapping("/view")
	public String viewPayment(@RequestParam("id") String SettlementId, Model model) {
		System.out.println(Integer.parseInt(SettlementId));
		//get Payment by id
		Payments payment = paymentsServiceInterface.getPaymentById(Integer.parseInt(SettlementId));
		model.addAttribute("payment", payment);
		return "paymentDetails";
	}
	
	//to filter payments by server side
	@GetMapping("/search")
	public String searchPaymentsByPaymentId(@RequestParam("filterBy") String type, @RequestParam("value") String value,
			Model model) {
		System.out.println(value + type);
		//get filtered Payments
		List<Payments> filteredData = paymentsServiceInterface.filterList(type, value);
		model.addAttribute("payments", filteredData);
		return "payments";
	}
}
