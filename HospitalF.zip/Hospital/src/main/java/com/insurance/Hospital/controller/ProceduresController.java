package com.insurance.Hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.DiseaseProcedures;
import  com.insurance.Hospital.contractors.*;


@Controller
public class ProceduresController {

	@Autowired(required = true)
	DiseaseProceduresServiceInterface disc;


	//To get procedures based on diseaseId
	@GetMapping(value = "/procedures/{diseaseId}")
	public String getProceduresByDisId(@PathVariable String diseaseId, Model model) {
		System.out.println("jhjhjh");
		List<DiseaseProcedures> procedures = disc.getProceduresByDisId(Integer.parseInt(diseaseId));
		System.out.println("jhjhjh");
		System.out.println(procedures);
		model.addAttribute("procedures", procedures);
		return "diseaseProcedures";
	}
}