package com.insurance.Hospital.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Hospital.contractors.ClaimServiceInterface;
import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.NonActivePolicyException;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.RequestedAmountException;
import com.insurance.Hospital.models.Uploads;
import com.insurance.Hospital.services.ClaimService;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class ClaimController {

	ClaimServiceInterface claimServiceInterface;

	private HttpSession httpSession;

	@Autowired
	public ClaimController(ClaimServiceInterface claimServiceInterface, HttpSession httpSession) {
		this.claimServiceInterface = claimServiceInterface;
		this.httpSession = httpSession;
	}

	// New Claim
	@GetMapping(value = "/newclaim")
	public String newClaim(Model model) {
		// it will to neew claim page
		return "SETCLAIMS";
	}

	@RequestMapping(value = "/claimbills", method = RequestMethod.POST)
	public String claimData(@RequestParam("file[]") MultipartFile[] files,
			@RequestParam("documentTitle") String[] documentNames, @RequestParam("claimAmount") String[] claimAmount,
			Claim claim, ClaimApplication application, Model model) {
		int policyId = claim.getClamIplcId();
		try {
			if (claimServiceInterface.checkPolicyIdStatus(policyId)) {
				// Raise Exception here
				throw new NonActivePolicyException("Invalid policy details provided.");
			}

		} catch (NonActivePolicyException ex) {
			// Handle the exception here, you can log it or display an error message.
			// This is just an example; you can implement proper error handling.
			// Return an error view or redirect to an error page if needed.
			model.addAttribute("errorMessage",
					"policy is not in active status,so you cannot claim with this details provided");
			return "exception";
		}
		try {
			if (!claimServiceInterface.checkRequestedAmount(application.getClamIplcId(),
					application.getClaimAmountRequested())) {
				throw new RequestedAmountException("Requested amount cannot be granted", "REQAMT001");
			}
			claimServiceInterface.addClaimApplication(application);
			claimServiceInterface.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested(),
					"IMS Hospital");
			Claim clm_id = claimServiceInterface.getClaimByid(claim.getClamIplcId());
			int cid = clm_id.getClamId();
			String uploadDir = "src/main/resources/static/file";

			try {
				// Create the target directory if it doesn't exist
				Files.createDirectories(Paths.get(uploadDir));
				int i = 0;
				for (MultipartFile file : files) {
					// Get the original file name
					String fileName = StringUtils.cleanPath(file.getOriginalFilename());

					// Create the target file path within the directory
					Path targetLocation = Paths.get(uploadDir).resolve(fileName);

					// Copy the file to the target location
					Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

					String fullPath = targetLocation.toAbsolutePath().toString();
					ClaimBills bill = new ClaimBills();
					bill.setClbl_document_path(fileName);
					bill.setClbl_document_path(documentNames[i]);
					bill.setClbl_claim_amount(Double.parseDouble(claimAmount[i]));
					bill.setClam_id(cid);
					claimServiceInterface.addClaimBills(bill);

				}

				// After successfully storing all files, you can redirect to a success page or
				// return a response accordingly
				return "SETCLAIMS";
			} catch (IOException ex) {
				ex.printStackTrace();

			}

			return "SETCLAIMS";
		} catch (RequestedAmountException ex) {
			System.out.println("Caught CustomException: " + ex.getMsg());
			model.addAttribute("errorCode", ex.getErrorCode());
			model.addAttribute("errorMessage", ex.getMsg());

			return "errorPage";
		}
	}

	// to list all family members by his policy id
	@GetMapping(value = "/getFamilyMembers")
	public ResponseEntity<List<String>> getFamily(@RequestParam("policy") int id, Model model) {
		// Finding family memebers by policy id
		List<String> members = claimServiceInterface.getFamilyByPolicy(id);
		return ResponseEntity.ok(members);
	}

	// ListClaims
	@GetMapping(value = "/getAllClaims")
	public String getAllClaims(Model model) {
		System.out.println("madh");
		// All Claims lists here
		ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getAllClaims();
		// setting all claims into model to display in html page
		model.addAttribute("claims", li);
		return "listclaims";
	}

	@PostMapping(value = "/viewClaim")
	public String getClaimById(Model model, @RequestParam("clamId") int clamId) {
		System.out.println("madh");
		// Finding claim by its claimId
		Claim cl = claimServiceInterface.getClaimById(clamId);
		model.addAttribute("claim", cl);
		return "viewclaim";
	}

	// filtering claims
	@GetMapping(value = "/getFilteredClaims")
	public String getFilteredClaims(Model model, @RequestParam("status") String status) {
		System.out.println("madh");
		// Finding claims filtered by filtered values
		ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getFilteredClaims(status);
		model.addAttribute("claims", li);
		return "listclaims";
	}

	// Downloading excel with filters on server side
	@RequestMapping(value = "/excel", method = RequestMethod.POST)
	public void downloadExcel(@RequestParam("selectedStatus") String status, HttpServletResponse response)
			throws IOException {
		claimServiceInterface.downloadExcel(status, response);
	}

	// Upload

	@GetMapping(value = "/getrequired")
	public String getRequiredUploads(@RequestParam("claimid") int id, Model model) {
		if (!claimServiceInterface.getAllReUploads(id).isEmpty()) {
			model.addAttribute("reupload", claimServiceInterface.getAllReUploads(id));
			model.addAttribute("claimid", id);
			return "update";
		} else {
			model.addAttribute("claimid", id);
			return "status";
		}
	}

	@PostMapping(value = "/adduploads")
	public String addUploads(@RequestParam("claimid") String id, MultipartHttpServletRequest request, Model model) {

		int claimId = Integer.parseInt(id);
		int index = 1;

		List<ReUpload> list = claimServiceInterface.getAllReUploads(claimId);
		List<Uploads> list2 = claimServiceInterface.getAllUploads(claimId);

		if (list2.size() > 0) {

			index = list2.get(list2.size()).getReUploadId();
		}
		// iterating through to uploaded list
		for (ReUpload upload : list) {
			System.out.println("loop");
			// entering only if claim id matches
			if (upload.getClaimId() == claimId) {
				String name = upload.getName();
				System.out.println("loop");
				MultipartFile file = request.getFile(name);
				if (file != null) {
					// transferinf files into below given location
					String uploadDir = "src/main/resources/static/file";
					try {
						// it creates path if it is not there
						Files.createDirectories(Paths.get(uploadDir));

						String fileName = StringUtils.cleanPath(file.getOriginalFilename());
						Path targetLocation = Paths.get(uploadDir).resolve(fileName);
						Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
						String fullPath = targetLocation.toAbsolutePath().toString();

						Uploads up = new Uploads();
						up.setUploadId(index);
						up.setReUploadId(upload.getUploadId());
						up.setClaimId(claimId);
						up.setData(fullPath);
						up.setType("file");

						claimServiceInterface.addUploads(up);
						claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);

					} catch (IOException ex) {
						ex.printStackTrace();
					}
				} else {

					Uploads up = new Uploads();

					up.setUploadId(index);
					up.setReUploadId(upload.getUploadId());
					up.setClaimId(claimId);
					up.setData(request.getParameter(name));
					up.setType("text");

					claimServiceInterface.addUploads(up);
					claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);
				}

			}
		}

		model.addAttribute("claimid", claimId);
		return "viewclaim";
	}
}